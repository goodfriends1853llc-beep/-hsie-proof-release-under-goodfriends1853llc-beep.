# HFAP-001 — Human Freedom & Autonomy Protection Standard

**Version:** 0.1.0  
**Status:** ENGINEERING CANDIDATE / GOVERNED VERSIONED ARTIFACT / NOT CANONICAL  
**Front:** F — Human sovereignty / HFAP  
**TB-SUB-001:** UNCHANGED  
**MIA:** UNCHANGED  
**Authority dependency:** HSA-CON-001 exact version/status remains UNVERIFIED

## Purpose

HFAP protects the human's authority over disclosure, interpretation, consent, correction, participation, action and exit when HSIE systems assist, represent, recommend or act within an authorized scope.

## Normative controls

1. Human report, evidence, system interpretation, recommendation, authority and action SHALL remain distinguishable.
2. Consent SHALL be active, scoped and separately recorded; silence, prior consent, payment, identity or participation SHALL NOT imply new consent.
3. The human SHALL be able to refuse, skip, correct, narrow, pause, resume where permitted, and withdraw.
4. Withdrawal SHALL stop future governed participation under the withdrawn scope; it SHALL NOT silently erase preserved history or lawful retention obligations.
5. An AI/system proposal SHALL NOT become an executed action merely because it was generated.
6. Consequential action SHALL require the necessary human confirmation and separately valid execution authority.
7. Denied, refused, expired, paused, out-of-scope or unauthorized actions SHALL produce no governed mutation except the denial/refusal record itself.
8. Irreversible or high-consequence action SHALL require explicit human confirmation under an active scope.
9. Unresolved conflict of interest, coercive pressure/manipulation indicators, or authority ambiguity SHALL block consequential action pending review.
10. No interface SHALL use hidden scoring, fabricated certainty, false urgency, or undisclosed authority to push a human decision.
11. Corrections SHALL preserve history and the relationship to the superseded representation.
12. Human-control behavior SHALL be measurable through refusal, pause, withdrawal, correction, denial/no-mutation and burden/overtrust instrumentation where applicable.
13. Measurement SHALL NOT itself be represented as field validation.
14. A displayed policy SHALL NOT be described as technically enforced unless an actual control enforces it.

## Current implementation relationship

`runtime/wave1_runtime.py` implements a bounded local reference for proposal separation, scoped permission, pause/resume, withdrawal, correction, refusal, conflict-of-interest blocking, pressure-signal blocking, authority checking and denial/no-mutation receipts.

## Claim ceiling

This artifact closes the missing *versioned artifact* condition at the engineering-candidate level only. It is not a constitutional/canonical HFAP standard until the governing authority dependency is resolved. Field effectiveness remains unvalidated.
