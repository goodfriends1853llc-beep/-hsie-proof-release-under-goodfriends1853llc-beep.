# Human Explanation & Accessibility — EXPLANATION_CONTROL_M-001

**Version:** 0.1.0  
**Status:** ENGINEERING CANDIDATE / LOCAL REFERENCE IMPLEMENTATION / NOT CANONICAL  
**Phase:** HSIE ANAT Phase 5 execution  
**Front:** M — Human Explanation & Accessibility  
**Runtime:** `runtime/waves2_6_runtime.py :: ExplanationEngine`  
**TB-SUB-001:** UNCHANGED  
**MIA:** UNCHANGED

## Implemented local reference controls

- why/evidence/unknown/change-condition fields
- authority/data-treatment disclosure
- plain/expert detail modes
- accessibility metadata
- challenge route
- uncertainty/provenance visualization

## Boundary

This artifact establishes a bounded local control implementation only. It does not by itself establish ecosystem deployment, production security, real external effects, independent assurance, field validation, legal jurisdiction, public release, or canonical authority.

`CUSTODY-ANAT-001` remains controlling for unrecovered raw source wording.
