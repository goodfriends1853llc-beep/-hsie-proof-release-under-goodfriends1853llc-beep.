# External Dependency & Federation — EXTERNAL_CONTROL_K-001

**Version:** 0.1.0  
**Status:** ENGINEERING CANDIDATE / LOCAL REFERENCE IMPLEMENTATION / NOT CANONICAL  
**Phase:** HSIE ANAT Phase 5 execution  
**Front:** K — External Dependency & Federation  
**Runtime:** `runtime/waves2_6_runtime.py :: ExternalConnectorEngine`  
**TB-SUB-001:** UNCHANGED  
**MIA:** UNCHANGED

## Implemented local reference controls

- provider registry
- purpose/authority-bound calls
- provider failure receipt
- provider result epistemic ceiling
- provider substitution by compatible capability

## Boundary

This artifact establishes a bounded local control implementation only. It does not by itself establish ecosystem deployment, production security, real external effects, independent assurance, field validation, legal jurisdiction, public release, or canonical authority.

`CUSTODY-ANAT-001` remains controlling for unrecovered raw source wording.
