# HSIE Authority & Identity Control Contract — AIC-001

**Version:** 0.1.0  
**Status:** ENGINEERING CANDIDATE / LOCAL REFERENCE IMPLEMENTATION / NOT CANONICAL  
**Front:** A — Identity / authority lifecycle  
**TB-SUB-001:** UNCHANGED  
**MIA:** UNCHANGED  
**Authority dependency:** HSA-CON-001 exact version/status remains UNVERIFIED

## Boundary

Identity is not authentication, consent, payment, authority, completion, or truth about the whole human.
Authority is a bounded relationship with issuer, subject, scope, effective interval, status, provenance and evidence.

No local code in this package may create constitutional authority. Any `CONSTITUTIONAL` grant is rejected unless a separately verified constitutional basis is supplied to the runtime.

## Implemented reference controls

- stable entity registration and explicit duplicate rejection;
- alias/correction history without silent identity overwrite;
- candidate matching without automatic merge;
- evidence + authority required for explicit merge;
- scoped authority grants with effective interval and revocation;
- bounded delegation with no scope broadening;
- succession designation with no scope broadening;
- transport envelope that explicitly states identity reference is not authentication/consent;
- release-state changes behind explicit release authority;
- append-only hash-linked event history and replay.

## Claim ceiling

This artifact and its runtime establish a local reference implementation and internal test evidence only. They do not establish HSA constitutional authority, ecosystem deployment, field validation, or canonical adoption.
