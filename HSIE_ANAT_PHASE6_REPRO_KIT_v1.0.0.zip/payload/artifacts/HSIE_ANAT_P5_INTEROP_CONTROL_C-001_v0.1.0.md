# Interoperability Contracts — INTEROP_CONTROL_C-001

**Version:** 0.1.0  
**Status:** ENGINEERING CANDIDATE / LOCAL REFERENCE IMPLEMENTATION / NOT CANONICAL  
**Phase:** HSIE ANAT Phase 5 execution  
**Front:** C — Interoperability Contracts  
**Runtime:** `runtime/waves2_6_runtime.py :: InteropEngine`  
**TB-SUB-001:** UNCHANGED  
**MIA:** UNCHANGED

## Implemented local reference controls

- versioned contracts and schema checks
- explicit dependency/version records
- message idempotency and receipts
- authority + provenance on messages
- transfer receipt != target-use proof
- explicit compatibility

## Boundary

This artifact establishes a bounded local control implementation only. It does not by itself establish ecosystem deployment, production security, real external effects, independent assurance, field validation, legal jurisdiction, public release, or canonical authority.

`CUSTODY-ANAT-001` remains controlling for unrecovered raw source wording.
