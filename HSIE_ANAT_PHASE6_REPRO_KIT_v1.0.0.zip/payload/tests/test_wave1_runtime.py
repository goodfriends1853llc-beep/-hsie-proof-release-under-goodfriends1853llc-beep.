import unittest
from runtime.wave1_runtime import *

class Wave1TestBase(unittest.TestCase):
    def setUp(self):
        self.a=AuthorityIdentityEngine()
        for eid, typ, name in [("owner","PERSON","Owner"),("human","PERSON","Human"),("reviewer","PERSON","Reviewer"),("inst","INSTITUTION","Institution")]:
            self.a.register_entity(eid,typ,name)
        self.a.issue_grant(AuthorityGrant("g-owner","owner","owner",(
            "identity.merge","identity.transport","release.manage","authority.revoke",
            "institution.register","policy.manage","redress.review","redress.resolve",
            "credential.issue","credential.revoke","discipline.record","commons.manage","human.action"
        ),1,None,"BOUNDED_OWNER"))

class TestAuthority(Wave1TestBase):
    def test_constitutional_grant_rejected_without_verified_basis(self):
        with self.assertRaisesRegex(ControlError,"constitutional_authority_unverified"):
            self.a.issue_grant(AuthorityGrant("g-con","owner","owner",("*",),1,None,"CONSTITUTIONAL","HSA-CON-001-v1"))
    def test_duplicate_identity_rejected(self):
        with self.assertRaises(ControlError): self.a.register_entity("owner","PERSON")
    def test_name_candidate_does_not_auto_merge(self):
        self.a.register_entity("owner2","PERSON","Owner")
        self.assertEqual(self.a.find_candidates_by_name("Owner"),["owner","owner2"])
        self.assertEqual(self.a.entities["owner2"]["status"],"ACTIVE")
    def test_identity_merge_requires_evidence(self):
        self.a.register_entity("x","PERSON","X")
        with self.assertRaisesRegex(ControlError,"merge_requires_evidence"):
            self.a.merge_entities("owner","x","g-owner",[])
    def test_identity_merge_requires_authority(self):
        self.a.register_entity("x","PERSON","X")
        self.a.issue_grant(AuthorityGrant("g-human","owner","human",("identity.transport",),1,None,"BOUNDED_OWNER"))
        with self.assertRaises(ControlError): self.a.merge_entities("owner","x","g-human",["ev"])
    def test_identity_correction_preserves_alias(self):
        self.a.correct_display_name("human","Human Corrected","E1")
        self.assertIn("Human",self.a.aliases["human"])
    def test_expired_grant_denied(self):
        self.a.issue_grant(AuthorityGrant("g-exp","owner","human",("x",),1,2,"BOUNDED_OWNER"))
        self.assertFalse(self.a.is_authorized("human","x",3,"g-exp"))
    def test_revoke_removes_authority(self):
        self.a.issue_grant(AuthorityGrant("g-h","owner","human",("x",),1,None,"BOUNDED_OWNER"))
        self.a.revoke_grant("g-h","owner","E2")
        self.assertFalse(self.a.is_authorized("human","x",999,"g-h"))
    def test_delegation_cannot_broaden_scope(self):
        self.a.issue_grant(AuthorityGrant("g-del","owner","human",("a",),1,None,"BOUNDED_OWNER"))
        with self.assertRaisesRegex(ControlError,"delegation_scope_broadening"):
            self.a.issue_grant(AuthorityGrant("g-child","human","reviewer",("a","b"),2,None,"DELEGATED",predecessor_grant_id="g-del"))
    def test_successor_cannot_broaden_scope(self):
        self.a.issue_grant(AuthorityGrant("g-succ","owner","human",("a",),1,None,"BOUNDED_OWNER"))
        with self.assertRaisesRegex(ControlError,"succession_scope_broadening"):
            self.a.designate_successor("g-succ","g-next","reviewer",("a","b"),10)
    def test_successor_narrow_scope_allowed(self):
        self.a.issue_grant(AuthorityGrant("g-succ","owner","human",("a","b"),1,None,"BOUNDED_OWNER"))
        self.a.designate_successor("g-succ","g-next","reviewer",("a",),10)
        self.assertTrue(self.a.is_authorized("reviewer","a",10,"g-next"))
    def test_transport_envelope_states_identity_is_not_auth(self):
        self.a.issue_transport_envelope("T1","human","A","B","bounded","g-owner")
        self.assertIn("identity_reference_is_not_authentication_or_consent", self.a.ledger.events[-1].payload["warning"])
    def test_release_requires_authority(self):
        self.a.issue_grant(AuthorityGrant("g-no","owner","human",("identity.transport",),1,None,"BOUNDED_OWNER"))
        with self.assertRaises(ControlError): self.a.register_release("R1","A1","human","g-no","CANDIDATE")
    def test_release_history_is_append_only(self):
        self.a.register_release("R1","A1","owner","g-owner","CANDIDATE")
        self.a.register_release("R1","A1","owner","g-owner","PRIVATE_AUTHORIZED")
        self.assertEqual(sum(e.event_type=="RELEASE_STATE_CHANGED" for e in self.a.ledger.events),2)
    def test_ledger_verifies(self): self.assertTrue(self.a.ledger.verify())
    def test_replay_contains_corrections(self):
        self.a.correct_display_name("human","H2","E")
        self.assertTrue(any(e["event_type"]=="IDENTITY_CORRECTED" for e in self.a.replay_entity("human")["events"]))

class TestHFAP(Wave1TestBase):
    def setUp(self):
        super().setUp(); self.h=HFAPEngine(self.a); self.h.register_human("human"); self.h.grant_scope("human","service")
    def proposal(self,pid="P1"): self.h.propose(pid,"human","draft","service","reason")
    def test_proposal_does_not_execute(self):
        self.proposal(); self.assertEqual(self.h.proposals["P1"]["status"],"PROPOSED")
    def test_missing_human_confirmation_denies(self):
        self.proposal(); r=self.h.evaluate_action("P1","owner","human.action","g-owner",False); self.assertFalse(r["allowed"])
    def test_denied_action_no_mutation_marker(self):
        self.proposal(); self.h.evaluate_action("P1","owner","human.action","g-owner",False)
        self.assertTrue(self.h.ledger.events[-1].payload["no_mutation"])
    def test_ungranted_scope_denies(self):
        self.h.propose("P2","human","draft","marketing","reason")
        self.assertFalse(self.h.evaluate_action("P2","owner","human.action","g-owner",True)["allowed"])
    def test_pause_denies(self):
        self.h.pause("human"); self.proposal(); self.assertFalse(self.h.evaluate_action("P1","owner","human.action","g-owner",True)["allowed"])
    def test_resume_restores_eligibility(self):
        self.h.pause("human"); self.h.resume("human"); self.proposal(); self.assertTrue(self.h.evaluate_action("P1","owner","human.action","g-owner",True)["allowed"])
    def test_withdraw_denies(self):
        self.h.withdraw("human"); self.proposal(); self.assertFalse(self.h.evaluate_action("P1","owner","human.action","g-owner",True)["allowed"])
    def test_withdraw_cannot_resume(self):
        self.h.withdraw("human");
        with self.assertRaises(ControlError): self.h.resume("human")
    def test_correction_appends_history(self):
        self.h.correct("human","rec1","corrected"); self.assertEqual(self.h.state["human"]["corrections"][0]["record_ref"],"rec1")
    def test_refusal_is_valid_event(self):
        self.h.refuse("human","REQ1"); self.assertEqual(self.h.metrics["refusals"],1)
    def test_conflict_of_interest_blocks(self):
        self.proposal(); r=self.h.evaluate_action("P1","owner","human.action","g-owner",True,conflict_of_interest=True); self.assertFalse(r["allowed"])
    def test_pressure_signal_blocks(self):
        self.proposal(); r=self.h.evaluate_action("P1","owner","human.action","g-owner",True,pressure_flags=["urgency"]); self.assertFalse(r["allowed"])
    def test_authorized_bounded_action_can_pass(self):
        self.proposal(); r=self.h.evaluate_action("P1","owner","human.action","g-owner",True); self.assertTrue(r["allowed"])
    def test_revoked_scope_blocks_future_action(self):
        self.h.revoke_scope("human","service"); self.proposal(); self.assertFalse(self.h.evaluate_action("P1","owner","human.action","g-owner",True)["allowed"])
    def test_metrics_capture_controls(self):
        self.proposal(); self.h.evaluate_action("P1","owner","human.action","g-owner",False)
        m=self.h.measurement_snapshot(); self.assertEqual((m["action_requests"],m["denied"]),(1,1))
    def test_hfap_ledger_verifies(self): self.assertTrue(self.h.ledger.verify())

class TestInstitutionGovernance(Wave1TestBase):
    def setUp(self):
        super().setUp(); self.g=InstitutionGovernanceEngine(self.a); self.g.register_institution("I1","Local Institution","owner","g-owner")
    def test_institution_requires_authority(self):
        self.a.issue_grant(AuthorityGrant("g-bad","owner","human",("x",),1,None,"BOUNDED_OWNER"))
        with self.assertRaises(ControlError): self.g.register_institution("I2","Bad","human","g-bad")
    def test_policy_version_no_silent_overwrite(self):
        self.g.register_policy("P","I1","1","r","owner","g-owner")
        with self.assertRaisesRegex(ControlError,"same_version_overwrite_forbidden"):
            self.g.register_policy("P","I1","1","changed","owner","g-owner")
    def test_policy_successor_preserves_prior_event(self):
        self.g.register_policy("P","I1","1","r1","owner","g-owner")
        self.g.register_policy("P","I1","2","r2","owner","g-owner","ACTIVE")
        self.assertEqual(sum(e.event_type=="POLICY_VERSION_RECORDED" for e in self.g.ledger.events),2)
    def test_grievance_requires_evidence_to_resolve(self):
        self.g.open_grievance("G1","I1","human","issue"); self.g.route_grievance("G1","owner","g-owner")
        with self.assertRaises(ControlError): self.g.resolve_grievance("G1","owner","g-owner","deny",[])
    def test_grievance_appeal_path(self):
        self.g.open_grievance("G1","I1","human","issue"); self.g.route_grievance("G1","owner","g-owner"); self.g.resolve_grievance("G1","owner","g-owner","correct",["E"]); self.g.appeal_grievance("G1","still disputed")
        self.assertEqual(self.g.grievances["G1"]["status"],"APPEALED")
    def test_appeal_before_resolution_rejected(self):
        self.g.open_grievance("G1","I1","human","issue")
        with self.assertRaises(ControlError): self.g.appeal_grievance("G1","x")
    def test_credential_issue_and_revoke(self):
        self.g.issue_credential("C1","human","ROLE","owner","g-owner",50); self.assertTrue(self.g.credential_is_active("C1",10)); self.g.revoke_credential("C1","owner","g-owner","reason"); self.assertFalse(self.g.credential_is_active("C1",10))
    def test_credential_expiry(self):
        self.g.issue_credential("C1","human","ROLE","owner","g-owner",5); self.assertFalse(self.g.credential_is_active("C1",6))
    def test_discipline_requires_evidence(self):
        with self.assertRaises(ControlError): self.g.record_discipline("D1","human","warning","owner","g-owner",[],True)
    def test_discipline_keeps_appeal_flag(self):
        self.g.record_discipline("D1","human","warning","owner","g-owner",["E"],True); self.assertTrue(self.g.discipline["D1"]["appeal_available"])
    def test_external_law_claim_requires_source(self):
        with self.assertRaisesRegex(ControlError,"external_law_requires_source"):
            self.g.register_jurisdiction_profile("J1","I1","internal","Florida law says x")
    def test_external_law_claim_with_source_is_attributed(self):
        self.g.register_jurisdiction_profile("J1","I1","internal","External claim","SRC")
        self.assertEqual(self.g.jurisdictions["J1"]["external_source_ref"],"SRC")
    def test_commons_rule_requires_authority(self):
        self.g.register_commons_rule("CM1","public read, governed write","owner","g-owner"); self.assertIn("CM1",self.g.commons)
    def test_governance_ledger_verifies(self): self.assertTrue(self.g.ledger.verify())

if __name__ == '__main__':
    unittest.main(verbosity=2)
