from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Dict, List, Tuple, Optional, Any
import hashlib
import json

ZERO_HASH = "0" * 64


def canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha(obj: Any) -> str:
    return hashlib.sha256(canonical(obj).encode("utf-8")).hexdigest()


class ControlError(ValueError):
    pass


@dataclass(frozen=True)
class Event:
    seq: int
    event_type: str
    payload: Dict[str, Any]
    prev_hash: str
    event_hash: str


class AppendOnlyLedger:
    def __init__(self):
        self._events: List[Event] = []

    def append(self, event_type: str, payload: Dict[str, Any]) -> Event:
        seq = len(self._events) + 1
        prev = self._events[-1].event_hash if self._events else ZERO_HASH
        core = {"seq": seq, "event_type": event_type, "payload": payload, "prev_hash": prev}
        ev = Event(seq, event_type, payload, prev, sha(core))
        self._events.append(ev)
        return ev

    @property
    def events(self) -> Tuple[Event, ...]:
        return tuple(self._events)

    def verify(self) -> bool:
        prev = ZERO_HASH
        for idx, ev in enumerate(self._events, start=1):
            if ev.seq != idx or ev.prev_hash != prev:
                return False
            core = {"seq": ev.seq, "event_type": ev.event_type, "payload": ev.payload, "prev_hash": ev.prev_hash}
            if ev.event_hash != sha(core):
                return False
            prev = ev.event_hash
        return True

    def export(self) -> List[Dict[str, Any]]:
        return [asdict(e) for e in self._events]


@dataclass
class AuthorityGrant:
    grant_id: str
    issuer: str
    subject: str
    scopes: Tuple[str, ...]
    valid_from: int
    valid_until: Optional[int]
    authority_class: str
    constitutional_basis: Optional[str] = None
    predecessor_grant_id: Optional[str] = None
    status: str = "ACTIVE"


class AuthorityIdentityEngine:
    """Local reference controls. Does not create constitutional authority."""

    def __init__(self, verified_constitutional_basis: Optional[str] = None):
        self.verified_constitutional_basis = verified_constitutional_basis
        self.ledger = AppendOnlyLedger()
        self.entities: Dict[str, Dict[str, Any]] = {}
        self.aliases: Dict[str, List[str]] = {}
        self.grants: Dict[str, AuthorityGrant] = {}
        self.releases: Dict[str, Dict[str, Any]] = {}

    def register_entity(self, entity_id: str, entity_type: str, display_name: Optional[str] = None):
        if entity_id in self.entities:
            raise ControlError("duplicate_entity_id")
        self.entities[entity_id] = {"entity_type": entity_type, "display_name": display_name, "status": "ACTIVE"}
        self.aliases[entity_id] = []
        self.ledger.append("ENTITY_REGISTERED", {"entity_id": entity_id, "entity_type": entity_type, "display_name": display_name})

    def add_alias(self, entity_id: str, alias: str):
        self._require_entity(entity_id)
        if alias not in self.aliases[entity_id]:
            self.aliases[entity_id].append(alias)
        self.ledger.append("IDENTITY_ALIAS_ADDED", {"entity_id": entity_id, "alias": alias})

    def correct_display_name(self, entity_id: str, new_name: str, evidence_ref: str):
        self._require_entity(entity_id)
        old = self.entities[entity_id].get("display_name")
        if old:
            self.add_alias(entity_id, old)
        self.entities[entity_id]["display_name"] = new_name
        self.ledger.append("IDENTITY_CORRECTED", {"entity_id": entity_id, "old": old, "new": new_name, "evidence_ref": evidence_ref})

    def find_candidates_by_name(self, name: str) -> List[str]:
        n = name.casefold()
        out = []
        for eid, rec in self.entities.items():
            names = [rec.get("display_name") or ""] + self.aliases.get(eid, [])
            if any(x.casefold() == n for x in names):
                out.append(eid)
        return sorted(out)

    def merge_entities(self, primary_id: str, secondary_id: str, authority_grant_id: str, evidence_refs: List[str]):
        self._require_entity(primary_id); self._require_entity(secondary_id)
        if not evidence_refs:
            raise ControlError("merge_requires_evidence")
        if not self.is_authorized(self.grants[authority_grant_id].subject, "identity.merge", at_seq=len(self.ledger.events)+1, grant_id=authority_grant_id):
            raise ControlError("merge_not_authorized")
        self.entities[secondary_id]["status"] = "SUPERSEDED_BY:" + primary_id
        self.ledger.append("IDENTITY_MERGED", {"primary_id": primary_id, "secondary_id": secondary_id, "authority_grant_id": authority_grant_id, "evidence_refs": evidence_refs})

    def issue_grant(self, grant: AuthorityGrant):
        self._require_entity(grant.issuer); self._require_entity(grant.subject)
        if grant.grant_id in self.grants:
            raise ControlError("duplicate_grant_id")
        if not grant.scopes:
            raise ControlError("empty_scope")
        if grant.valid_until is not None and grant.valid_until < grant.valid_from:
            raise ControlError("invalid_validity_window")
        if grant.authority_class == "CONSTITUTIONAL":
            if not self.verified_constitutional_basis or grant.constitutional_basis != self.verified_constitutional_basis:
                raise ControlError("constitutional_authority_unverified")
        if grant.predecessor_grant_id:
            parent = self.grants.get(grant.predecessor_grant_id)
            if not parent or parent.status != "ACTIVE":
                raise ControlError("invalid_predecessor")
            if grant.issuer != parent.subject:
                raise ControlError("delegation_issuer_not_grantee")
            if not set(grant.scopes).issubset(set(parent.scopes)):
                raise ControlError("delegation_scope_broadening")
        self.grants[grant.grant_id] = grant
        self.ledger.append("AUTHORITY_GRANTED", asdict(grant))

    def revoke_grant(self, grant_id: str, actor: str, evidence_ref: str):
        g = self.grants[grant_id]
        if actor != g.issuer and not self.is_authorized(actor, "authority.revoke", at_seq=len(self.ledger.events)+1):
            raise ControlError("revoke_not_authorized")
        g.status = "REVOKED"
        self.ledger.append("AUTHORITY_REVOKED", {"grant_id": grant_id, "actor": actor, "evidence_ref": evidence_ref})

    def is_authorized(self, subject: str, scope: str, at_seq: int, grant_id: Optional[str] = None) -> bool:
        grants = [self.grants[grant_id]] if grant_id else list(self.grants.values())
        for g in grants:
            if g.subject != subject or g.status != "ACTIVE":
                continue
            if at_seq < g.valid_from or (g.valid_until is not None and at_seq > g.valid_until):
                continue
            if scope in g.scopes or "*" in g.scopes:
                return True
        return False

    def designate_successor(self, predecessor_grant_id: str, successor_grant_id: str, successor_entity: str, scopes: Tuple[str, ...], at_seq: int):
        parent = self.grants[predecessor_grant_id]
        if not set(scopes).issubset(set(parent.scopes)):
            raise ControlError("succession_scope_broadening")
        child = AuthorityGrant(
            grant_id=successor_grant_id, issuer=parent.subject, subject=successor_entity,
            scopes=scopes, valid_from=at_seq, valid_until=parent.valid_until,
            authority_class="DELEGATED", predecessor_grant_id=predecessor_grant_id,
        )
        self.issue_grant(child)
        self.ledger.append("SUCCESSOR_DESIGNATED", {"predecessor_grant_id": predecessor_grant_id, "successor_grant_id": successor_grant_id})

    def issue_transport_envelope(self, envelope_id: str, entity_id: str, source_context: str, target_context: str, purpose: str, authority_grant_id: str):
        self._require_entity(entity_id)
        g = self.grants[authority_grant_id]
        if not self.is_authorized(g.subject, "identity.transport", len(self.ledger.events)+1, authority_grant_id):
            raise ControlError("transport_not_authorized")
        self.ledger.append("IDENTITY_TRANSPORT_ENVELOPE_ISSUED", {
            "envelope_id": envelope_id, "entity_id": entity_id, "source_context": source_context,
            "target_context": target_context, "purpose": purpose, "authority_grant_id": authority_grant_id,
            "warning": "identity_reference_is_not_authentication_or_consent"
        })

    def register_release(self, release_id: str, artifact_id: str, actor: str, authority_grant_id: str, state: str):
        if state not in {"CANDIDATE","PRIVATE_AUTHORIZED","PUBLIC_AUTHORIZED","WITHDRAWN","SUPERSEDED"}:
            raise ControlError("invalid_release_state")
        if not self.is_authorized(actor, "release.manage", len(self.ledger.events)+1, authority_grant_id):
            raise ControlError("release_not_authorized")
        prev = self.releases.get(release_id)
        self.releases[release_id] = {"artifact_id":artifact_id,"state":state,"authority_grant_id":authority_grant_id}
        self.ledger.append("RELEASE_STATE_CHANGED", {"release_id":release_id,"artifact_id":artifact_id,"prior":prev,"state":state,"authority_grant_id":authority_grant_id})

    def replay_entity(self, entity_id: str) -> Dict[str, Any]:
        events = [asdict(e) for e in self.ledger.events if entity_id in canonical(e.payload)]
        return {"entity_id": entity_id, "current": self.entities.get(entity_id), "aliases": self.aliases.get(entity_id, []), "events": events}

    def _require_entity(self, entity_id: str):
        if entity_id not in self.entities:
            raise ControlError("unknown_entity")


class HFAPEngine:
    """Human-sovereignty enforcement reference. Representation of policy is separate from enforcement."""

    def __init__(self, authority: AuthorityIdentityEngine):
        self.authority = authority
        self.ledger = AppendOnlyLedger()
        self.state: Dict[str, Dict[str, Any]] = {}
        self.proposals: Dict[str, Dict[str, Any]] = {}
        self.metrics = {
            "action_requests":0, "allowed":0, "denied":0, "pause_events":0, "withdraw_events":0,
            "corrections":0, "refusals":0, "override_denials":0, "pressure_blocks":0, "coi_blocks":0,
        }

    def register_human(self, human_id: str):
        if human_id in self.state:
            raise ControlError("duplicate_human")
        self.state[human_id] = {"scopes": set(), "paused": False, "withdrawn": False, "corrections": []}
        self.ledger.append("HUMAN_REGISTERED", {"human_id":human_id})

    def grant_scope(self, human_id: str, scope: str):
        s=self._s(human_id); s["scopes"].add(scope)
        self.ledger.append("HUMAN_SCOPE_GRANTED", {"human_id":human_id,"scope":scope})

    def revoke_scope(self, human_id: str, scope: str):
        s=self._s(human_id); s["scopes"].discard(scope)
        self.ledger.append("HUMAN_SCOPE_REVOKED", {"human_id":human_id,"scope":scope})

    def pause(self, human_id: str):
        self._s(human_id)["paused"]=True; self.metrics["pause_events"]+=1
        self.ledger.append("HUMAN_PAUSED", {"human_id":human_id})

    def resume(self, human_id: str):
        s=self._s(human_id)
        if s["withdrawn"]: raise ControlError("withdrawn_cannot_resume_without_new_enrollment")
        s["paused"]=False
        self.ledger.append("HUMAN_RESUMED", {"human_id":human_id})

    def withdraw(self, human_id: str):
        s=self._s(human_id); s["withdrawn"]=True; s["paused"]=True; self.metrics["withdraw_events"]+=1
        self.ledger.append("HUMAN_WITHDREW", {"human_id":human_id})

    def correct(self, human_id: str, record_ref: str, correction: str):
        s=self._s(human_id); s["corrections"].append({"record_ref":record_ref,"correction":correction}); self.metrics["corrections"]+=1
        self.ledger.append("HUMAN_CORRECTION_RECORDED", {"human_id":human_id,"record_ref":record_ref,"correction":correction})

    def refuse(self, human_id: str, request_id: str):
        self._s(human_id); self.metrics["refusals"]+=1
        self.ledger.append("HUMAN_REFUSED", {"human_id":human_id,"request_id":request_id})

    def propose(self, proposal_id: str, human_id: str, action: str, scope: str, rationale: str):
        self._s(human_id)
        if proposal_id in self.proposals: raise ControlError("duplicate_proposal")
        self.proposals[proposal_id] = {"human_id":human_id,"action":action,"scope":scope,"rationale":rationale,"status":"PROPOSED"}
        self.ledger.append("ACTION_PROPOSED", {"proposal_id":proposal_id, **self.proposals[proposal_id]})

    def evaluate_action(self, proposal_id: str, actor: str, authority_scope: str, authority_grant_id: str,
                        human_confirmed: bool, irreversible: bool=False, conflict_of_interest: bool=False,
                        pressure_flags: Optional[List[str]]=None) -> Dict[str, Any]:
        self.metrics["action_requests"] += 1
        p=self.proposals[proposal_id]; s=self._s(p["human_id"])
        reasons=[]
        if s["withdrawn"]: reasons.append("human_withdrawn")
        if s["paused"]: reasons.append("human_paused")
        if p["scope"] not in s["scopes"]: reasons.append("scope_not_granted")
        if not self.authority.is_authorized(actor, authority_scope, len(self.authority.ledger.events)+1, authority_grant_id): reasons.append("actor_not_authorized")
        if not human_confirmed: reasons.append("human_confirmation_missing")
        if irreversible and not human_confirmed: reasons.append("irreversible_without_confirmation")
        if conflict_of_interest:
            reasons.append("conflict_of_interest_unresolved"); self.metrics["coi_blocks"] += 1
        if pressure_flags:
            reasons.append("pressure_or_manipulation_signal"); self.metrics["pressure_blocks"] += 1
        allowed=not reasons
        if allowed:
            p["status"]="AUTHORIZED_FOR_BOUNDED_EXECUTION"; self.metrics["allowed"]+=1
            self.ledger.append("ACTION_AUTHORIZED", {"proposal_id":proposal_id,"actor":actor,"authority_grant_id":authority_grant_id})
        else:
            p["status"]="DENIED_NO_MUTATION"; self.metrics["denied"]+=1; self.metrics["override_denials"]+=1
            self.ledger.append("ACTION_DENIED", {"proposal_id":proposal_id,"reasons":reasons,"no_mutation":True})
        return {"allowed":allowed,"reasons":reasons,"proposal_status":p["status"]}

    def measurement_snapshot(self) -> Dict[str, Any]:
        return dict(self.metrics)

    def _s(self, human_id):
        if human_id not in self.state: raise ControlError("unknown_human")
        return self.state[human_id]


class InstitutionGovernanceEngine:
    """Local governance workflow reference; cannot create external law or constitutional authority."""

    def __init__(self, authority: AuthorityIdentityEngine):
        self.authority=authority
        self.ledger=AppendOnlyLedger()
        self.institutions={}
        self.policies={}
        self.grievances={}
        self.credentials={}
        self.discipline={}
        self.jurisdictions={}
        self.commons={}

    def register_institution(self, institution_id: str, name: str, actor: str, authority_grant_id: str):
        self._auth(actor,"institution.register",authority_grant_id)
        if institution_id in self.institutions: raise ControlError("duplicate_institution")
        self.institutions[institution_id]={"name":name,"status":"ACTIVE"}
        self.ledger.append("INSTITUTION_REGISTERED", {"institution_id":institution_id,"name":name,"authority_grant_id":authority_grant_id})

    def register_policy(self, policy_id: str, institution_id: str, version: str, rule: str, actor: str, authority_grant_id: str, status="CANDIDATE"):
        self._auth(actor,"policy.manage",authority_grant_id)
        if status not in {"CANDIDATE","ACTIVE","SUPERSEDED","WITHDRAWN"}: raise ControlError("invalid_policy_status")
        prev=self.policies.get(policy_id)
        if prev and prev["version"] == version: raise ControlError("same_version_overwrite_forbidden")
        self.policies[policy_id]={"institution_id":institution_id,"version":version,"rule":rule,"status":status}
        self.ledger.append("POLICY_VERSION_RECORDED", {"policy_id":policy_id,"institution_id":institution_id,"version":version,"status":status,"prior":prev,"authority_grant_id":authority_grant_id})

    def open_grievance(self, grievance_id: str, institution_id: str, complainant: str, issue: str):
        if grievance_id in self.grievances: raise ControlError("duplicate_grievance")
        self.grievances[grievance_id]={"institution_id":institution_id,"complainant":complainant,"issue":issue,"status":"SUBMITTED","history":["SUBMITTED"]}
        self.ledger.append("GRIEVANCE_SUBMITTED", {"grievance_id":grievance_id,"institution_id":institution_id,"complainant":complainant,"issue":issue})

    def route_grievance(self, grievance_id: str, reviewer: str, authority_grant_id: str):
        self._auth(reviewer,"redress.review",authority_grant_id)
        g=self.grievances[grievance_id]; g["status"]="UNDER_REVIEW"; g["history"].append("UNDER_REVIEW")
        self.ledger.append("GRIEVANCE_ROUTED", {"grievance_id":grievance_id,"reviewer":reviewer,"authority_grant_id":authority_grant_id})

    def resolve_grievance(self, grievance_id: str, reviewer: str, authority_grant_id: str, disposition: str, evidence_refs: List[str]):
        self._auth(reviewer,"redress.resolve",authority_grant_id)
        if not evidence_refs: raise ControlError("resolution_requires_evidence")
        g=self.grievances[grievance_id]; g["status"]="RESOLVED"; g["disposition"]=disposition; g["history"].append("RESOLVED")
        self.ledger.append("GRIEVANCE_RESOLVED", {"grievance_id":grievance_id,"reviewer":reviewer,"disposition":disposition,"evidence_refs":evidence_refs,"authority_grant_id":authority_grant_id})

    def appeal_grievance(self, grievance_id: str, reason: str):
        g=self.grievances[grievance_id]
        if g["status"] != "RESOLVED": raise ControlError("appeal_requires_resolution")
        g["status"]="APPEALED"; g["history"].append("APPEALED")
        self.ledger.append("GRIEVANCE_APPEALED", {"grievance_id":grievance_id,"reason":reason})

    def issue_credential(self, credential_id: str, subject: str, credential_type: str, actor: str, authority_grant_id: str, expires_at: Optional[int]=None):
        self._auth(actor,"credential.issue",authority_grant_id)
        if credential_id in self.credentials: raise ControlError("duplicate_credential")
        self.credentials[credential_id]={"subject":subject,"type":credential_type,"status":"ACTIVE","expires_at":expires_at}
        self.ledger.append("CREDENTIAL_ISSUED", {"credential_id":credential_id,"subject":subject,"type":credential_type,"expires_at":expires_at,"authority_grant_id":authority_grant_id})

    def credential_is_active(self, credential_id: str, at_seq: int) -> bool:
        c=self.credentials[credential_id]
        return c["status"]=="ACTIVE" and (c["expires_at"] is None or at_seq <= c["expires_at"])

    def revoke_credential(self, credential_id: str, actor: str, authority_grant_id: str, reason: str):
        self._auth(actor,"credential.revoke",authority_grant_id)
        self.credentials[credential_id]["status"]="REVOKED"
        self.ledger.append("CREDENTIAL_REVOKED", {"credential_id":credential_id,"reason":reason,"authority_grant_id":authority_grant_id})

    def record_discipline(self, record_id: str, subject: str, action: str, actor: str, authority_grant_id: str, evidence_refs: List[str], appeal_available: bool):
        self._auth(actor,"discipline.record",authority_grant_id)
        if not evidence_refs: raise ControlError("discipline_requires_evidence")
        self.discipline[record_id]={"subject":subject,"action":action,"status":"ACTIVE_RECORD","evidence_refs":list(evidence_refs),"appeal_available":appeal_available}
        self.ledger.append("DISCIPLINE_RECORDED", {"record_id":record_id,"subject":subject,"action":action,"evidence_refs":evidence_refs,"appeal_available":appeal_available,"authority_grant_id":authority_grant_id})

    def register_jurisdiction_profile(self, profile_id: str, institution_id: str, internal_scope: str, external_law_claim: Optional[str]=None, external_source_ref: Optional[str]=None):
        if external_law_claim and not external_source_ref:
            raise ControlError("external_law_requires_source")
        self.jurisdictions[profile_id]={"institution_id":institution_id,"internal_scope":internal_scope,"external_law_claim":external_law_claim,"external_source_ref":external_source_ref}
        self.ledger.append("JURISDICTION_PROFILE_RECORDED", {"profile_id":profile_id, **self.jurisdictions[profile_id]})

    def register_commons_rule(self, commons_id: str, rule: str, actor: str, authority_grant_id: str):
        self._auth(actor,"commons.manage",authority_grant_id)
        self.commons[commons_id]={"rule":rule}
        self.ledger.append("COMMONS_RULE_RECORDED", {"commons_id":commons_id,"rule":rule,"authority_grant_id":authority_grant_id})

    def _auth(self, actor, scope, grant_id):
        if grant_id not in self.authority.grants or not self.authority.is_authorized(actor, scope, len(self.authority.ledger.events)+1, grant_id):
            raise ControlError("governance_action_not_authorized")
