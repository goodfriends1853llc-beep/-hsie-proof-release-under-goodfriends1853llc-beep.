import json
from runtime.wave1_runtime import AuthorityIdentityEngine, AuthorityGrant, HFAPEngine, ControlError, sha
from runtime.waves2_6_runtime import *

checks=[]
def ck(name, passed, detail): checks.append({'check':name,'pass':bool(passed),'detail':detail})

# Build bounded local path.
a=AuthorityIdentityEngine()
for eid,typ in [('owner','PERSON'),('human','PERSON')]: a.register_entity(eid,typ,eid)
a.issue_grant(AuthorityGrant('g','owner','owner',('human.action','identity.transport','release.manage'),1,8,'BOUNDED_OWNER'))
h=HFAPEngine(a); h.register_human('human'); h.grant_scope('human','service')
interop=InteropEngine(); interop.register_contract('TASK','1',['id','purpose'])
sec=SecurityEngine(); sec.enroll('owner','credential',['execute']); sec.store_secret('provider-key','not-exposed')
priv=PrivacyEngine(); priv.create_record('R','human','service',{'fact':'x'},'SRC',100); priv.consent('C','human','service','runtime',['fact'])
ops=OperationsEngine(); ops.create_task('T','owner')
obs=ObservabilityEngine(); obs.register_metric('health'); obs.trace('TR','S','health','OK','phase5')
res=ResilienceEngine(); res.commit('task','before'); res.snapshot('S0')
exp=ExplanationEngine(); val=ValidationEngine(); val.preregister('VP',{'all_core_stages':True},'PT-001')
q=IntegrationProofEngine(); ext=ExternalConnectorEngine(); ext.register_provider('p','lookup')

# Accepted path
auth_ok=a.is_authorized('owner','human.action',5,'g')
h.propose('P','human','bounded action','service','test')
hf=h.evaluate_action('P','owner','human.action','g',True)
contract=interop.message('M1','TASK','1',{'id':'T','purpose':'proof'},'g','SRC')
authn=sec.authenticate('owner','credential') and sec.authorize('owner','execute')
disc=priv.disclose('R','C','runtime','service',['fact'])
ops.advance_task('T','REVIEWED'); ops.advance_task('T','ROUTED'); ops.advance_task('T','ACTIONED')
res.commit('task','after'); effect=(res.current['task']=='after')
restore=res.restore('S0')
ex=exp.explain('RESULT','bounded proof',['SRC'],['field validation not established'],['external evidence'],'g','bounded local record','plain')
accepted=q.run(identity_ok=True,authority_ok=auth_ok,hfap_ok=hf['allowed'],contract_ok=contract['status']=='ACCEPTED',security_ok=authn,privacy_ok=disc['allowed'],operations_ok=ops.tasks['T']['status']=='ACTIONED',observed_effect=effect,recovery_ok=restore,explanation_ok=bool(ex))
ck('accepted_end_to_end_path',accepted['status']=='PASS',accepted)

# 1 stale authority
a_stale=AuthorityIdentityEngine(); a_stale.register_entity('o','PERSON'); a_stale.issue_grant(AuthorityGrant('stale','o','o',('x',),1,1,'BOUNDED_OWNER'))
ck('challenge_01_stale_authority',not a_stale.is_authorized('o','x',2,'stale'),'expired grant denied')

# 2 unauthorized transition
ops2=OperationsEngine(); ops2.create_task('T','o')
try: ops2.advance_task('T','ACTIONED'); ok=False; detail='unexpected pass'
except Exception as e: ok=str(e)=='invalid_task_transition'; detail=str(e)
ck('challenge_02_unauthorized_transition',ok,detail)

# 3 scope mismatch
p2=PrivacyEngine(); p2.create_record('R','h','service',{'x':1},'S',10); p2.consent('C','h','service','dest',['x'])
ck('challenge_03_scope_mismatch',not p2.disclose('R','C','dest','marketing',['x'])['allowed'],'purpose mismatch denied')

# 4 tampered evidence/hash
r4=ResilienceEngine(); r4.commit('x',1); r4.snapshot('S'); r4.snapshots['S']['state']['x']=2
try: r4.restore('S'); ok=False; detail='unexpected pass'
except Exception as e: ok=str(e)=='corrupt_snapshot'; detail=str(e)
ck('challenge_04_tampered_evidence',ok,detail)

# 5 schema mismatch
ck('challenge_05_schema_mismatch',interop.message('M2','TASK','1',{'id':'T'},'g','SRC')['status']=='REJECTED','missing purpose rejected')

# 6 provider failure
ext.set_health('p','DOWN'); ck('challenge_06_provider_failure',ext.call('REQ','p','lookup','g',{})['status']=='PROVIDER_FAILURE','provider failure receipted')

# 7 corrupted recovery artifact (separate explicit)
r7=ResilienceEngine(); r7.commit('a',1); r7.snapshot('S'); r7.snapshots['S']['digest']='0'*64
try: r7.restore('S'); ok=False; detail='unexpected pass'
except Exception as e: ok=str(e)=='corrupt_snapshot'; detail=str(e)
ck('challenge_07_corrupted_recovery_artifact',ok,detail)

# 8 duplicate/replayed request is idempotent
first=interop.message('M-DUP','TASK','1',{'id':'1','purpose':'x'},'g','SRC'); second=interop.message('M-DUP','TASK','1',{'id':'DIFFERENT','purpose':'different'},'g','SRC')
ck('challenge_08_duplicate_request',first==second,'duplicate request returns original receipt')

# 9 missing evidence
from runtime.wave1_runtime import InstitutionGovernanceEngine
ig=InstitutionGovernanceEngine(a); a.issue_grant(AuthorityGrant('gov','owner','owner',('institution.register','redress.review','redress.resolve'),1,None,'BOUNDED_OWNER')); ig.register_institution('I','i','owner','gov'); ig.open_grievance('GR','I','human','issue'); ig.route_grievance('GR','owner','gov')
try: ig.resolve_grievance('GR','owner','gov','x',[]); ok=False; detail='unexpected pass'
except Exception as e: ok=str(e)=='resolution_requires_evidence'; detail=str(e)
ck('challenge_09_missing_evidence',ok,detail)

# 10 explanation after denied action
a2=AuthorityIdentityEngine(); a2.register_entity('o','PERSON'); a2.register_entity('h','PERSON'); a2.issue_grant(AuthorityGrant('g','o','o',('human.action',),1,None,'BOUNDED_OWNER')); hh=HFAPEngine(a2); hh.register_human('h'); hh.grant_scope('h','s'); hh.propose('PX','h','act','s','r'); deny=hh.evaluate_action('PX','o','human.action','g',False)
e2=ExplanationEngine(); dx=e2.explain('PX','Action denied because explicit human confirmation was missing',['ACTION_DENIED'],['future intent'],['active explicit confirmation'],'g','denial event preserved')
ck('challenge_10_explanation_after_failure',(not deny['allowed']) and 'denied' in dx['why'].lower(),dx)

report={
 'proof_id':'PT-001',
 'status':'PASS' if all(c['pass'] for c in checks) else 'FAIL',
 'claim_ceiling':'BOUNDED LOCAL REFERENCE PROOF / NOT PRODUCTION / NOT FIELD VALIDATION / NO EXTERNAL PHYSICAL OR FINANCIAL EFFECT',
 'checks':checks,
 'summary':{'checks':len(checks),'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks)},
 'accepted_receipt_hash':accepted['receipt_hash'],
 'limitations':['HSA-CON-001 remains unverified','HFAP field validation remains open','external/provider/financial/physical effects remain unproven outside local simulation/reference controls']
}
print(json.dumps(report,indent=2,sort_keys=True))
raise SystemExit(0 if report['status']=='PASS' else 1)
