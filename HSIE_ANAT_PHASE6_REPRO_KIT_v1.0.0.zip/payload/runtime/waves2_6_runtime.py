from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Tuple
import hashlib, json, re
from runtime.wave1_runtime import AppendOnlyLedger, ControlError, sha, canonical


class InteropEngine:
    def __init__(self):
        self.ledger=AppendOnlyLedger(); self.contracts={}; self.dependencies={}; self.receipts={}
    def register_contract(self, contract_id, version, required_fields, compatible_with=()):
        key=(contract_id,version)
        if key in self.contracts: raise ControlError('duplicate_contract_version')
        self.contracts[key]={'required_fields':tuple(required_fields),'compatible_with':tuple(compatible_with)}
        self.ledger.append('CONTRACT_REGISTERED',{'contract_id':contract_id,'version':version,'required_fields':list(required_fields),'compatible_with':list(compatible_with)})
    def validate(self, contract_id, version, payload):
        c=self.contracts.get((contract_id,version))
        if not c: return {'ok':False,'fault':'unknown_contract_version'}
        missing=[k for k in c['required_fields'] if k not in payload]
        return {'ok':not missing,'fault':None if not missing else 'missing_required_fields','missing':missing}
    def register_dependency(self, dep_id, version, status):
        prior=self.dependencies.get(dep_id)
        self.dependencies[dep_id]={'version':version,'status':status}
        self.ledger.append('DEPENDENCY_RECORDED',{'dep_id':dep_id,'version':version,'status':status,'prior':prior})
    def compatibility(self, contract_id, source_version, target_version):
        if source_version==target_version: return True
        c=self.contracts.get((contract_id,target_version))
        return bool(c and source_version in c['compatible_with'])
    def message(self, message_id, contract_id, version, payload, authority_ref, provenance_ref):
        if message_id in self.receipts: return self.receipts[message_id]
        if not authority_ref or not provenance_ref: raise ControlError('message_requires_authority_and_provenance')
        check=self.validate(contract_id,version,payload)
        if not check['ok']:
            rec={'message_id':message_id,'status':'REJECTED','fault':check['fault'],'missing':check.get('missing',[])}
        else:
            rec={'message_id':message_id,'status':'ACCEPTED','contract_id':contract_id,'version':version,'payload_hash':sha(payload),'authority_ref':authority_ref,'provenance_ref':provenance_ref}
        self.receipts[message_id]=rec; self.ledger.append('MESSAGE_RECEIPT',rec); return rec
    def transfer(self, transfer_id, source, target, artifact_hash, authority_ref, purpose):
        if not all([source,target,artifact_hash,authority_ref,purpose]): raise ControlError('incomplete_transfer_contract')
        rec={'transfer_id':transfer_id,'source':source,'target':target,'artifact_hash':artifact_hash,'authority_ref':authority_ref,'purpose':purpose,'status':'TRANSFER_RECORDED_NOT_PROOF_OF_TARGET_USE'}
        self.ledger.append('TRANSFER_RECORDED',rec); return rec


class SecurityEngine:
    def __init__(self):
        self.ledger=AppendOnlyLedger(); self.credentials={}; self.scopes={}; self.secrets={}; self.rate={}; self.vulns={}
    def enroll(self, principal, credential, scopes):
        self.credentials[principal]=sha({'credential':credential}); self.scopes[principal]=set(scopes)
        self.ledger.append('PRINCIPAL_ENROLLED',{'principal':principal,'scopes':sorted(scopes)})
    def authenticate(self, principal, credential):
        ok=self.credentials.get(principal)==sha({'credential':credential})
        self.ledger.append('AUTHN_RESULT',{'principal':principal,'ok':ok}); return ok
    def authorize(self, principal, scope):
        ok=scope in self.scopes.get(principal,set()) or '*' in self.scopes.get(principal,set())
        self.ledger.append('AUTHZ_RESULT',{'principal':principal,'scope':scope,'ok':ok}); return ok
    def store_secret(self, secret_id, value):
        self.secrets[secret_id]=sha({'secret':value}); self.ledger.append('SECRET_STORED',{'secret_id':secret_id,'digest':self.secrets[secret_id]})
    def reveal_secret(self, secret_id): raise ControlError('secret_retrieval_prohibited_in_reference_runtime')
    def inspect_untrusted(self, text):
        patterns=[r'ignore previous instructions',r'<script',r'BEGIN PRIVATE KEY',r'password\s*=',r'system prompt']
        hits=[p for p in patterns if re.search(p,text,re.I)]
        result={'safe':not hits,'hits':hits}; self.ledger.append('UNTRUSTED_INPUT_INSPECTED',result); return result
    def dlp(self, payload):
        text=canonical(payload)
        hits=[]
        if re.search(r'\b\d{3}-\d{2}-\d{4}\b',text): hits.append('US_SSN_PATTERN')
        if 'BEGIN PRIVATE KEY' in text: hits.append('PRIVATE_KEY_MATERIAL')
        result={'allowed':not hits,'hits':hits}; self.ledger.append('DLP_RESULT',result); return result
    def rate_limit(self, principal, window_id, max_count):
        k=(principal,window_id); self.rate[k]=self.rate.get(k,0)+1
        allowed=self.rate[k] <= max_count; self.ledger.append('RATE_LIMIT_RESULT',{'principal':principal,'window_id':window_id,'count':self.rate[k],'allowed':allowed}); return allowed
    def vulnerability(self, vuln_id, severity, evidence_ref, status='OPEN'):
        self.vulns[vuln_id]={'severity':severity,'evidence_ref':evidence_ref,'status':status}; self.ledger.append('VULNERABILITY_RECORDED',{'vuln_id':vuln_id,**self.vulns[vuln_id]})
    def close_vulnerability(self,vuln_id,evidence_ref,retest_pass):
        if not retest_pass: raise ControlError('vulnerability_retest_failed')
        self.vulns[vuln_id]['status']='CLOSED_VERIFIED'; self.ledger.append('VULNERABILITY_CLOSED',{'vuln_id':vuln_id,'evidence_ref':evidence_ref,'retest_pass':True})


class PrivacyEngine:
    def __init__(self):
        self.ledger=AppendOnlyLedger(); self.records={}; self.consents={}; self.holds=set(); self.publications={}
    def create_record(self, record_id, subject, purpose, fields, provenance_ref, retention_until):
        if not provenance_ref: raise ControlError('provenance_required')
        self.records[record_id]={'subject':subject,'purpose':purpose,'fields':dict(fields),'provenance_ref':provenance_ref,'retention_until':retention_until,'status':'ACTIVE','history':[]}
        self.ledger.append('DATA_RECORD_CREATED',{'record_id':record_id,'subject':subject,'purpose':purpose,'field_names':sorted(fields),'provenance_ref':provenance_ref,'retention_until':retention_until})
    def consent(self, consent_id, subject, purpose, recipient, fields, active=True):
        self.consents[consent_id]={'subject':subject,'purpose':purpose,'recipient':recipient,'fields':set(fields),'active':active}; self.ledger.append('CONSENT_RECORDED',{'consent_id':consent_id,'subject':subject,'purpose':purpose,'recipient':recipient,'fields':sorted(fields),'active':active})
    def disclose(self, record_id, consent_id, recipient, purpose, fields):
        r=self.records[record_id]; c=self.consents[consent_id]
        allowed=c['active'] and c['subject']==r['subject'] and c['recipient']==recipient and c['purpose']==purpose and set(fields).issubset(c['fields']) and set(fields).issubset(r['fields'])
        rec={'record_id':record_id,'consent_id':consent_id,'recipient':recipient,'purpose':purpose,'fields':sorted(fields),'allowed':allowed}
        self.ledger.append('DISCLOSURE_DECISION',rec); return rec
    def correct(self, record_id, field, value, evidence_ref):
        r=self.records[record_id]; old=r['fields'].get(field); r['history'].append({'field':field,'old':old,'new':value,'evidence_ref':evidence_ref}); r['fields'][field]=value
        self.ledger.append('DATA_CORRECTED',{'record_id':record_id,'field':field,'old':old,'new':value,'evidence_ref':evidence_ref})
    def legal_hold(self, record_id, reason): self.holds.add(record_id); self.ledger.append('LEGAL_HOLD_SET',{'record_id':record_id,'reason':reason})
    def delete(self, record_id, actor, authority_ref):
        if record_id in self.holds: raise ControlError('legal_hold_blocks_delete')
        self.records[record_id]['status']='DELETED_TOMBSTONE'; self.records[record_id]['fields']={}
        self.ledger.append('DATA_DELETED',{'record_id':record_id,'actor':actor,'authority_ref':authority_ref})
    def export(self, record_id):
        r=self.records[record_id]; return {'record_id':record_id,'subject':r['subject'],'purpose':r['purpose'],'fields':dict(r['fields']),'provenance_ref':r['provenance_ref'],'history':list(r['history']),'status':r['status']}
    def retention_due(self, record_id, at_seq): return at_seq > self.records[record_id]['retention_until']
    def publish(self, publication_id, record_id, authorization_ref):
        if not authorization_ref: raise ControlError('publication_authorization_required')
        self.publications[publication_id]={'record_id':record_id,'authorization_ref':authorization_ref,'status':'PUBLIC_AUTHORIZED_NOT_PROOF_OF_PUBLICATION'}
        self.ledger.append('PUBLICATION_AUTHORIZED',{'publication_id':publication_id,**self.publications[publication_id]})
    def mosaic(self, values: List[int], minimum_group_size: int):
        if len(values)<minimum_group_size: raise ControlError('aggregation_group_too_small')
        return {'count':len(values),'sum':sum(values),'mean_num':sum(values),'mean_den':len(values)}


class OperationsEngine:
    def __init__(self):
        self.ledger=AppendOnlyLedger(); self.tasks={}; self.incidents={}; self.near_misses={}; self.capa={}; self.services={}
    def create_task(self, task_id, owner, dependencies=()): self.tasks[task_id]={'owner':owner,'dependencies':list(dependencies),'status':'RECEIVED'}; self.ledger.append('TASK_CREATED',{'task_id':task_id,'owner':owner,'dependencies':list(dependencies)})
    def advance_task(self, task_id, to_state, dependency_states=None):
        allowed={'RECEIVED':['REVIEWED'],'REVIEWED':['ROUTED'],'ROUTED':['ACTIONED'],'ACTIONED':['RESOLVED'],'RESOLVED':['CLOSED']}
        cur=self.tasks[task_id]['status']
        if to_state not in allowed.get(cur,[]): raise ControlError('invalid_task_transition')
        if to_state in {'ACTIONED','RESOLVED','CLOSED'} and self.tasks[task_id]['dependencies']:
            states=dependency_states or {}; missing=[d for d in self.tasks[task_id]['dependencies'] if states.get(d)!='HEALTHY']
            if missing: raise ControlError('dependency_not_healthy')
        self.tasks[task_id]['status']=to_state; self.ledger.append('TASK_STATE_CHANGED',{'task_id':task_id,'prior':cur,'state':to_state})
    def incident(self, incident_id, evidence_ref, severity): self.incidents[incident_id]={'evidence_ref':evidence_ref,'severity':severity,'status':'OPEN'}; self.ledger.append('INCIDENT_RECORDED',{'incident_id':incident_id,**self.incidents[incident_id]})
    def near_miss(self, near_id, evidence_ref): self.near_misses[near_id]={'evidence_ref':evidence_ref,'status':'OPEN'}; self.ledger.append('NEAR_MISS_RECORDED',{'near_id':near_id,'evidence_ref':evidence_ref})
    def open_capa(self,capa_id,source_id,root_cause,corrective,preventive):
        if not corrective or not preventive: raise ControlError('capa_requires_corrective_and_preventive')
        self.capa[capa_id]={'source_id':source_id,'root_cause':root_cause,'corrective':corrective,'preventive':preventive,'status':'OPEN','effectiveness':None}; self.ledger.append('CAPA_OPENED',{'capa_id':capa_id,**self.capa[capa_id]})
    def close_capa(self,capa_id,effectiveness_pass):
        if not effectiveness_pass: raise ControlError('effectiveness_review_failed')
        self.capa[capa_id]['status']='CLOSED_VERIFIED'; self.capa[capa_id]['effectiveness']=True; self.ledger.append('CAPA_CLOSED',{'capa_id':capa_id,'effectiveness_pass':True})
    def service_health(self, service_id, desired, current): self.services[service_id]={'desired':desired,'current':current}; self.ledger.append('SERVICE_HEALTH_RECORDED',{'service_id':service_id,'desired':desired,'current':current}); return desired==current


class ObservabilityEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.vocab=set(); self.traces={}; self.baselines={}; self.alerts={}; self.alert_counts={}
    def register_metric(self,name): self.vocab.add(name); self.ledger.append('METRIC_REGISTERED',{'name':name})
    def trace(self,trace_id,span_id,metric,value,source):
        if metric not in self.vocab: raise ControlError('unknown_metric')
        self.traces.setdefault(trace_id,[]).append({'span_id':span_id,'metric':metric,'value':value,'source':source}); self.ledger.append('TRACE_SPAN',{'trace_id':trace_id,'span_id':span_id,'metric':metric,'value':value,'source':source})
    def set_baseline(self,key,value): self.baselines[key]=value; self.ledger.append('BASELINE_SET',{'key':key,'value':value})
    def drift(self,key,current,tolerance):
        if key not in self.baselines: return {'state':'UNKNOWN','reason':'no_baseline'}
        delta=abs(current-self.baselines[key]); return {'state':'DRIFT' if delta>tolerance else 'WITHIN_BASELINE','delta':delta}
    def alert(self,key,severity,message,max_per_window=2,window='default'):
        k=(key,window); self.alert_counts[k]=self.alert_counts.get(k,0)+1
        emitted=self.alert_counts[k] <= max_per_window
        rec={'key':key,'severity':severity,'message':message,'window':window,'emitted':emitted,'suppressed_for_fatigue':not emitted}; self.ledger.append('ALERT_EVALUATED',rec); return rec
    def health_map(self):
        latest={}
        for spans in self.traces.values():
            for s in spans: latest[s['metric']]=s['value']
        return latest


class ResilienceEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.snapshots={}; self.current={}; self.remediation={}
    def commit(self,key,value): self.current[key]=value; self.ledger.append('STATE_COMMITTED',{'key':key,'value':value})
    def snapshot(self,snapshot_id):
        snap=json.loads(json.dumps(self.current,sort_keys=True)); digest=sha(snap); self.snapshots[snapshot_id]={'state':snap,'digest':digest}; self.ledger.append('SNAPSHOT_CREATED',{'snapshot_id':snapshot_id,'digest':digest}); return digest
    def validate_snapshot(self,snapshot_id): return sha(self.snapshots[snapshot_id]['state'])==self.snapshots[snapshot_id]['digest']
    def restore(self,snapshot_id):
        if not self.validate_snapshot(snapshot_id): raise ControlError('corrupt_snapshot')
        pre=sha(self.current); self.current=json.loads(json.dumps(self.snapshots[snapshot_id]['state'])); post=sha(self.current); self.ledger.append('STATE_RESTORED',{'snapshot_id':snapshot_id,'pre_hash':pre,'post_hash':post,'verified':post==self.snapshots[snapshot_id]['digest']}); return post==self.snapshots[snapshot_id]['digest']
    def remediate(self,rem_id,affected_party,notification,proposal,status='PROPOSED'):
        self.remediation[rem_id]={'affected_party':affected_party,'notification':notification,'proposal':proposal,'status':status}; self.ledger.append('REMEDIATION_RECORDED',{'rem_id':rem_id,**self.remediation[rem_id]})


class ExplanationEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.challenges={}
    def explain(self,result_id,why,evidence,unknowns,change_conditions,authority,data_treatment,level='plain',accessibility=()):
        if level not in {'plain','expert'}: raise ControlError('invalid_detail_level')
        obj={'result_id':result_id,'why':why,'evidence':list(evidence),'unknowns':list(unknowns),'what_would_change':list(change_conditions),'authority':authority,'data_treatment':data_treatment,'detail_level':level,'accessibility':list(accessibility)}
        self.ledger.append('EXPLANATION_RENDERED',obj); return obj
    def challenge(self,challenge_id,result_id,claim,requested_correction): self.challenges[challenge_id]={'result_id':result_id,'claim':claim,'requested_correction':requested_correction,'status':'SUBMITTED'}; self.ledger.append('CHALLENGE_SUBMITTED',{'challenge_id':challenge_id,**self.challenges[challenge_id]})
    def visualization(self,explanation): return {'uncertainty':explanation['unknowns'],'provenance':explanation['evidence'],'revision_diff':'AVAILABLE_IF_SUCCESSOR_EXISTS','timeline':'EVENT_ORDER','relationships':'SOURCE_BOUND'}


class ValidationEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.protocols={}; self.benchmarks={}; self.results={}; self.external={}
    def preregister(self,protocol_id,criteria,scope): self.protocols[protocol_id]={'criteria':dict(criteria),'scope':scope,'locked':True}; self.ledger.append('VALIDATION_PROTOCOL_PREREGISTERED',{'protocol_id':protocol_id,'criteria':criteria,'scope':scope})
    def mutate_criteria(self,protocol_id,criteria):
        if self.protocols[protocol_id]['locked']: raise ControlError('criteria_locked_after_preregistration')
    def benchmark(self,benchmark_id,cases): self.benchmarks[benchmark_id]=list(cases); self.ledger.append('BENCHMARK_REGISTERED',{'benchmark_id':benchmark_id,'case_count':len(cases),'digest':sha(cases)})
    def binary_metrics(self,result_id,predictions,labels):
        if len(predictions)!=len(labels) or not predictions: raise ControlError('invalid_metric_input')
        tp=tn=fp=fn=0
        for p,y in zip(predictions,labels):
            if p and y: tp+=1
            elif p and not y: fp+=1
            elif not p and y: fn+=1
            else: tn+=1
        r={'tp':tp,'tn':tn,'fp':fp,'fn':fn,'n':len(labels)}; self.results[result_id]=r; self.ledger.append('VALIDATION_RESULT',{'result_id':result_id,**r}); return r
    def calibration_mae_basis_points(self, probs_bp, labels):
        if len(probs_bp)!=len(labels) or not probs_bp: raise ControlError('invalid_calibration_input')
        errs=[abs(p-(10000 if y else 0)) for p,y in zip(probs_bp,labels)]
        return sum(errs)//len(errs)
    def external_gate(self,gate_id,kind,provider,status='PENDING'):
        if kind not in {'INDEPENDENT_REPRODUCTION','EXTERNAL_PEER_REVIEW'}: raise ControlError('invalid_external_gate')
        self.external[gate_id]={'kind':kind,'provider':provider,'status':status}; self.ledger.append('EXTERNAL_ASSURANCE_GATE',{'gate_id':gate_id,**self.external[gate_id]})
    def readiness(self,verification_pass,security_pass,privacy_pass,hfap_pass,field_pass=False,independent_pass=False):
        prod=all([verification_pass,security_pass,privacy_pass,hfap_pass])
        public=prod and field_pass and independent_pass
        return {'production_readiness_internal':prod,'public_release_ready':public}


class SurvivalEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.dependencies={}; self.successors={}; self.shutdown_state='RUNNING'; self.record_exports={}
    def dependency_risk(self,dep_id,kind,criticality,fallback): self.dependencies[dep_id]={'kind':kind,'criticality':criticality,'fallback':fallback}; self.ledger.append('DEPENDENCY_RISK_RECORDED',{'dep_id':dep_id,**self.dependencies[dep_id]})
    def succession(self,role,current,successor,scope,authority_ref): self.successors[role]={'current':current,'successor':successor,'scope':scope,'authority_ref':authority_ref}; self.ledger.append('SUCCESSION_PLAN_RECORDED',{'role':role,**self.successors[role]})
    def shutdown(self,reason,authority_ref): self.shutdown_state='SHUTDOWN'; self.ledger.append('CATASTROPHIC_SHUTDOWN',{'reason':reason,'authority_ref':authority_ref})
    def dissolve(self,authority_ref,human_records):
        if self.shutdown_state!='SHUTDOWN': raise ControlError('dissolution_requires_shutdown')
        self.shutdown_state='DISSOLVED'; self.record_exports={k:v for k,v in human_records.items()}; self.ledger.append('ECOSYSTEM_DISSOLVED',{'authority_ref':authority_ref,'human_record_ids':sorted(human_records),'processing_authority_ended':True})


class ExternalConnectorEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.providers={}; self.receipts={}
    def register_provider(self,provider_id,capability,jurisdiction_ref=None): self.providers[provider_id]={'capability':capability,'jurisdiction_ref':jurisdiction_ref,'health':'UP'}; self.ledger.append('PROVIDER_REGISTERED',{'provider_id':provider_id,**self.providers[provider_id]})
    def set_health(self,provider_id,health): self.providers[provider_id]['health']=health; self.ledger.append('PROVIDER_HEALTH_CHANGED',{'provider_id':provider_id,'health':health})
    def call(self,request_id,provider_id,purpose,authority_ref,payload):
        if request_id in self.receipts: return self.receipts[request_id]
        p=self.providers[provider_id]
        status='PROVIDER_FAILURE' if p['health']!='UP' else 'PROVIDER_REPORTED_RESULT'
        rec={'request_id':request_id,'provider_id':provider_id,'purpose':purpose,'authority_ref':authority_ref,'request_hash':sha(payload),'status':status,'claim_ceiling':'provider_report_is_not_physical_or_legal_truth'}
        self.receipts[request_id]=rec; self.ledger.append('PROVIDER_CALL_RECEIPT',rec); return rec
    def substitute(self,old_provider,new_provider,capability):
        if self.providers[old_provider]['capability']!=capability or self.providers[new_provider]['capability']!=capability: raise ControlError('capability_mismatch')
        self.ledger.append('PROVIDER_SUBSTITUTION_RECORDED',{'old':old_provider,'new':new_provider,'capability':capability}); return True


class FinanceEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.accounts={}; self.entries={}; self.escrows={}; self.disputes={}
    def account(self,account_id): self.accounts.setdefault(account_id,0)
    def journal(self,entry_id,debits,credits,memo,authority_ref):
        if entry_id in self.entries: return self.entries[entry_id]
        if any(not isinstance(v,int) for v in list(debits.values())+list(credits.values())): raise ControlError('fixed_point_integers_required')
        if sum(debits.values())!=sum(credits.values()): raise ControlError('unbalanced_entry')
        for a,v in debits.items(): self.account(a); self.accounts[a]+=v
        for a,v in credits.items(): self.account(a); self.accounts[a]-=v
        rec={'entry_id':entry_id,'debits':debits,'credits':credits,'memo':memo,'authority_ref':authority_ref,'status':'LOCAL_LEDGER_POSTED'}; self.entries[entry_id]=rec; self.ledger.append('JOURNAL_POSTED',rec); return rec
    def external_settlement(self,*args,**kwargs): raise ControlError('external_settlement_provider_required')
    def escrow_open(self,escrow_id,amount_cents,conditions): self.escrows[escrow_id]={'amount_cents':amount_cents,'conditions':conditions,'status':'HELD_LOCAL_REPRESENTATION'}; self.ledger.append('ESCROW_RECORDED',{'escrow_id':escrow_id,**self.escrows[escrow_id]})
    def refund(self,refund_id,amount_cents,authority_ref): return self.journal(refund_id,{'refund_expense':amount_cents},{'cash_representation':amount_cents},'refund-local',authority_ref)
    def dispute(self,dispute_id,amount_cents,evidence_ref): self.disputes[dispute_id]={'amount_cents':amount_cents,'evidence_ref':evidence_ref,'status':'OPEN'}; self.ledger.append('DISPUTE_OPENED',{'dispute_id':dispute_id,**self.disputes[dispute_id]})


class PhysicalEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.devices={}; self.permissions={}; self.estop=False; self.effects={}
    def register_device(self,device_id,owner,custodian,attested): self.devices[device_id]={'owner':owner,'custodian':custodian,'attested':attested}; self.ledger.append('DEVICE_REGISTERED',{'device_id':device_id,**self.devices[device_id]})
    def grant_permission(self,device_id,capability,scope): self.permissions[(device_id,capability)]=scope; self.ledger.append('DEVICE_PERMISSION_GRANTED',{'device_id':device_id,'capability':capability,'scope':scope})
    def emergency_stop(self,active=True): self.estop=active; self.ledger.append('EMERGENCY_STOP_CHANGED',{'active':active})
    def actuate(self,command_id,device_id,capability,simulated,proximity_clear,geofence_ok=True):
        if self.estop: raise ControlError('emergency_stop_active')
        if not self.devices.get(device_id,{}).get('attested'): raise ControlError('device_not_attested')
        if (device_id,capability) not in self.permissions: raise ControlError('device_permission_missing')
        if not simulated: raise ControlError('physical_actuation_not_authorized_in_reference_runtime')
        if not proximity_clear or not geofence_ok: raise ControlError('physical_safety_interlock')
        rec={'command_id':command_id,'device_id':device_id,'capability':capability,'simulated':True,'command_status':'EXECUTED_IN_SIMULATION','effect_verified':False}; self.effects[command_id]=rec; self.ledger.append('ACTUATION_SIMULATED',rec); return rec
    def verify_effect(self,command_id,observed_effect,evidence_ref):
        r=self.effects[command_id]; r['effect_verified']=bool(observed_effect); r['effect_evidence_ref']=evidence_ref; self.ledger.append('PHYSICAL_EFFECT_VERIFIED',{'command_id':command_id,'observed_effect':bool(observed_effect),'evidence_ref':evidence_ref}); return r['effect_verified']


class DeveloperEngine:
    def __init__(self): self.ledger=AppendOnlyLedger(); self.developers={}; self.apps={}; self.packages={}; self.incidents={}
    def register_developer(self,developer_id,status='ACTIVE'): self.developers[developer_id]={'status':status}; self.ledger.append('DEVELOPER_REGISTERED',{'developer_id':developer_id,'status':status})
    def register_app(self,app_id,developer_id,scopes):
        if self.developers.get(developer_id,{}).get('status')!='ACTIVE': raise ControlError('developer_not_active')
        self.apps[app_id]={'developer_id':developer_id,'scopes':set(scopes),'status':'CANDIDATE'}; self.ledger.append('APP_REGISTERED',{'app_id':app_id,'developer_id':developer_id,'scopes':sorted(scopes)})
    def package(self,package_id,app_id,content,declared_scope):
        if declared_scope not in self.apps[app_id]['scopes']: raise ControlError('package_scope_not_granted')
        digest=hashlib.sha256(content).hexdigest(); self.packages[package_id]={'app_id':app_id,'digest':digest,'scope':declared_scope,'status':'REGISTERED'}; self.ledger.append('PACKAGE_REGISTERED',{'package_id':package_id,**self.packages[package_id]}); return digest
    def sandbox_effect(self,app_id,requested_scope):
        allowed=requested_scope in self.apps[app_id]['scopes']; self.ledger.append('SANDBOX_EFFECT_DECISION',{'app_id':app_id,'requested_scope':requested_scope,'allowed':allowed}); return allowed
    def release(self,package_id,verification_pass,security_pass):
        if not (verification_pass and security_pass): raise ControlError('release_gate_failed')
        self.packages[package_id]['status']='PRIVATE_RELEASE_AUTHORIZED'; self.ledger.append('PACKAGE_RELEASE_AUTHORIZED',{'package_id':package_id}); return True
    def revoke(self,package_id,reason): self.packages[package_id]['status']='REVOKED'; self.ledger.append('PACKAGE_REVOKED',{'package_id':package_id,'reason':reason})
    def incident(self,incident_id,app_id,evidence_ref): self.incidents[incident_id]={'app_id':app_id,'evidence_ref':evidence_ref,'status':'OPEN'}; self.ledger.append('THIRD_PARTY_INCIDENT_RECORDED',{'incident_id':incident_id,**self.incidents[incident_id]})


class IntegrationProofEngine:
    def __init__(self): self.ledger=AppendOnlyLedger()
    def run(self, *, identity_ok, authority_ok, hfap_ok, contract_ok, security_ok, privacy_ok, operations_ok, observed_effect, recovery_ok, explanation_ok):
        stages={'identity':identity_ok,'authority':authority_ok,'hfap':hfap_ok,'contract':contract_ok,'security':security_ok,'privacy':privacy_ok,'operations':operations_ok,'effect_observed':observed_effect,'recovery':recovery_ok,'explanation':explanation_ok}
        failed=[k for k,v in stages.items() if not v]
        status='PASS' if not failed else 'DENIED_OR_FAILED'
        rec={'stages':stages,'failed':failed,'status':status,'receipt_hash':sha({'stages':stages,'status':status})}
        self.ledger.append('INTEGRATION_PROOF_RESULT',rec); return rec
