# HSIE ANAT Phase 6 Reproduction Instructions

This kit supports reproduction of the bounded local reference implementation. It does not make the reproducer independent by itself.

1. Unpack the kit into a clean directory.
2. Use Python 3.13+ with pytest available.
3. From the unpacked payload root, run:
   `PYTHONPATH="$PWD" pytest -q tests`
4. Then run:
   `PYTHONPATH="$PWD" python runtime/run_pt001.py`
5. Compute SHA-256 values for the unpacked files and compare with `REPRO_MANIFEST.json`.
6. Record actor, organization, environment, date/time, any modifications, test output, PT-001 output, failures, and limitations.
7. Do not call the result independent reproduction unless the actor/team is genuinely independent from the builder and did not rely on builder-controlled execution or result interpretation.

Required claim ceiling: local reproduction evidence is not field validation, production deployment, external physical/financial effect, or constitutional authority.
